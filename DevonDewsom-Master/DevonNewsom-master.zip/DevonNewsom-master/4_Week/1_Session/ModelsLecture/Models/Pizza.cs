namespace ModelsLecture.Models
{
    public class Pizza
    {
        public string Name {get;set;}
        public string Topping {get;set;}
    }
}