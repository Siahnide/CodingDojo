﻿using System;
using OOPLOL.Stuff;

namespace OOPLOL
{
    class Program
    {
        static void Main(string[] args)
        {
            Corvette vette = new Corvette();
            vette.HonkHorn();
        }
    }
}
