## Git Repo for Instructor Devon 
### I will push lecture code up here, and possibly other goodies.
---
#### Check out my .gitignore for a pretty exaustive list for ASPDOTNETCOREMVC
